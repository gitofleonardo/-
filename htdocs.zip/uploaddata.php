<?php

class apply_result{
	public $success;
}
$result=new apply_result();

$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname="bookms";

$pictureDir="C://xampp/htdocs/temp/";   //图片存放地址
$pictureUrl="http://localhost:82/temp/";

$idCardImgFront="";
$idCardImgBack="";
$bankCardImg="";
$signature="";
$contracts="";
$ins="";
$signNameInput="";

$conn= mysqli_connect($servername,$username,$password);
	
mysqli_query($conn,"use ".$dbname);

if(!empty($_FILES['idCardImgFront']['tmp_name'])){
	move_uploaded_file($_FILES["idCardImgFront"]["tmp_name"],$pictureDir.$_POST["username"].date("YmdHisx")."jpg");
	$idCardImgFront=$pictureUrl.$_POST["username"].date("YmdHisx")."jpg";
}
if(!empty($_FILES['idCardImgBack']['tmp_name'])){
	move_uploaded_file($_FILES["idCardImgBack"]["tmp_name"],$pictureDir.$_POST["username"].date("YmdHisx")."jpg");
	$idCardImgBack=$pictureUrl.$_POST["username"].date("YmdHisx")."jpg";
}
if(!empty($_FILES['bankCardImg']['tmp_name'])){
	move_uploaded_file($_FILES["bankCardImg"]["tmp_name"],$pictureDir.$_POST["username"].date("YmdHisx")."jpg");
	$bankCardImg=$pictureUrl.$_POST["username"].date("YmdHisx")."jpg";
}
/*
if(!empty($_FILES['signature']['tmp_name'])){
	move_uploaded_file($_FILES["signature"]["tmp_name"],$pictureDir.$_POST["username"].date("YmdHisx")."jpg");
	$signature=$pictureUrl.$_POST["username"].date("YmdHisx")."jpg";
}*/
if(isset($_POST["signature"])){
	file_put_contents($pictureDir.$_POST["username"].date("YmdHisx")."jpg",base64_decode($_POST["signature"]));
	$signature=$pictureUrl.$_POST["username"].date("YmdHisx")."jpg";
}
if(isset($_POST["signNameInput"])){
	$signNameInput=$_POST["signNameInput"];
}

$sql=
"INSERT INTO applyInfo
(username,idCode,phone,company,userPost,entryTime,canbaoTime,originCompany,originCompanyLocation,bankCardNumber,bankName,applyAmount,signNameInput,idCardImgFront,idCardImgBack,bankCardImg,signature,contracts,ins)
 VALUES 
 ('".$_POST["username"]."','".$_POST["idCode"]."','".$_POST["phone"]."','".$_POST["company"]."','".$_POST["userPost"]."','".$_POST["entryTime"]."','".$_POST["canbaoTime"]."','".$_POST["originCompany"]."','".$_POST["originCompanyLocation"]."','".$_POST["bankCardNumber"]."','".$_POST["bankName"]."','".$_POST["applyAmount"]."','".$signNameInput."','".$idCardImgFront."','".$idCardImgBack."','".$bankCardImg."','".$signature."','".$contracts."','".$ins."')";
?>